# Beauty Salon Responsive Website 
### This is an HTML code for a website. It includes various sections such as header, sections for different services, member profiles, blog posts, and a footer. The website appears to be for a beauty salon or spa .

![camelia-baeuty-salon](https://github.com/dev-alihasan/beauty-salon/assets/101947194/41d25a80-d147-4683-8eac-3fc761b52850)
